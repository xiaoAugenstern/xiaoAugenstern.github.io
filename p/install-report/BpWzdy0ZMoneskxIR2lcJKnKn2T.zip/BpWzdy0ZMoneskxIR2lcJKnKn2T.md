# hugo 使用 stack 主题搭建博客及部署

> # 
>
> 。。。。

# ** 概念，搭建思路和运行环境**

## **什么是 GitHub Pages？**

GitHub Pages 是一组静态网页集合（Static Web Page），这些静态网页由 GitHub 托管（host）和发布，所以是 GitHub + Pages。

## **什么是 Hugo？**

Hugo 是用 Go 语言写的静态网站生成器（Static Site Generator）。可以把 Markdown 文件转化成 HTML 文件。

## **网站搭建思路**

1. 创建 2 个 GitHub 仓库

   - **博客源仓库**：储存所有 Markdown 源文件（博客内容），和博客中用到的图片等。
   - **GitHub Pages 仓库**：储存由 Hugo 从 Markdown 文件生成的 HTML 文件。
2. 将在博客源仓库中 Hugo 生成的静态 HTML 文件部署到远端 GitHub Pages 仓库中。

## ** 运行环境**

1. 了解基本的终端命令行知识，如：cd, ls
2. 安装了 Git，并且了解基本的 Git 知识
3. 有一个 GitHub 账号
4. 有自己偏好的代码编辑器（ VS Code ）
5. 有一个自己喜欢的主题 (我选择的 [Stack](https://themes.gohugo.io/themes/hugo-theme-stack/))

# **安装**

## **安装 Chocolatey**

（1）以管理员身份打开 cmd，右键以管理员身份运行，

![](static/BKp5bnGy6o40PxxHdk1cEfAbn2c.png)

（2）必须以管理员权限打开 cmd.exe 命令行提示，执行如下内容：

```python
@powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))" && SET PATH=%PATH%;%ALLUSERSPROFILE%\chocolatey\bin
```

还有一种安装方法，使用 PowerShell，同样必须以管理员权限打开 PowerShell，执行如下命令：

```python
iex ((new-object net.webclient).DownloadString('https://chocolatey.org/install.ps1'))
```

安装报错：

![](static/TyjbbDcI8oYEk2xHIUzcSwnbnlc.png)

只需要把 C:\ProgramData\chocolatey 这个目录删除，再重新执行安装程序就可以了。(不能科学上网)

检查是否安装成功：

```python
choco --version
```

![](static/GoGFbubAwo4isaxGT5Tc5Gt7nZg.png)

## 安装 hugo

![](static/Jf9IbRTxdo7TlFxE2Qnc75KSn0b)

命令行中安装 hugo：

```python
choco install hugo -confirm
```

安装 hugo-extended（扩展版本）：

```
choco install hugo-extended -confirm
```

检查 hugo 是否安装成功：

```
hugo version
```

![](static/InIabFTcfo0AhtxZif8c8qesnEe.png)

# **创建 GitHub 仓库**

## 参考

![](static/CdshbHjJZoEDhZxbF8XcIcsAnRb)

[如何用 GitHub Pages + Hugo 搭建个人博客](https://cuttontail.blog/blog/create-a-wesite-using-github-pages-and-hugo/#12-%E4%BB%80%E4%B9%88%E6%98%AF-hugo)

xiaoAugenstern.github.io 的 readme 后面要删除

## 遇到 bug

```python
HTTP/2 stream 1 was not closed cleanly before end of the underlying stream
```

解决方案：关闭所有的 github 连接，删除所有 github 页面

```
error: RPC failed; curl 92 HTTP/2 stream 0 was not closed cleanly: CANCEL (err 8)
error: 5968 bytes of body are still expected
fetch-pack: unexpected disconnect while reading sideband packet
fatal: early EOF
fatal: fetch-pack: invalid index-pack output
```

解决方案：重新换个 vpn

# 使用 stack 主题

## 克隆博客源仓库

到项目文件夹，克隆时使用的 HTTPS 仓库链接在这里查看：

```python
git clone https://github.com/xiaoAugenstern/xiaomanBlog.git
```

![](static/APlbbAxVzo3vRZxveaCcni6JnQe)

## hugo 创建网站文件夹

进入刚刚克隆下来的博客源仓库文件夹，在这个文件夹里用 Hugo 创建一个网站文件夹。

```python
cd xiaomanBlog
```

用 Hugo 创建网站文件夹的命令是 `hugo new site 网站名字`。

```python
hugo new site xiaoman-blog
```

用 Hugo 创建的网站共有 7 个文件夹和 1 个文件。

- archetypes：存放用 hugo 命令新建的 Markdown 文件应用的 front matter 模版
- content：存放内容页面，比如「博客」、「读书笔记」等
- layouts：存放定义网站的样式，写在 `layouts` 文件下的样式会覆盖安装的主题中的 `layouts` 文件同名的样式
- static：存放所有静态文件，如图片
- data：存放创建站点时 Hugo 使用的其他数据
- public：存放 Hugo 生成的静态网页
- themes：存放主题文件
- config.toml：网站配置文件

## 添加主题

```python
git submodule add https://github.com/CaiJimmy/hugo-theme-stack/ themes/hugo-theme-stack
cd themes
ls
```

![](static/OrYhbDPzGoHiTKxLgC2cVOmWnkb.png)
![](static/I4uGb4pgqo1VN9xadTGcQIbknJy.png)

## 修改配置文件

（1）`exampleSite` 的文件复制到站点目录

[hugo 建站(本地搭建)_hugo stack-CSDN 博客](https://blog.csdn.net/qq_41408081/article/details/120890571#:~:text=%23%20%E8%BF%9B%E5%85%A5%E4%BD%A0%E6%83%B3%E6%94%BE%E7%AB%99%E7%82%B9%E7%9A%84%E7%9B%AE%E5%BD%95%EF%BC%8C%E9%BC%A0%E6%A0%87%E5%8F%B3%E5%87%BB%E7%A9%BA%E7%99%BD%E5%A4%84%EF%BC%8C%E9%80%89%E6%8B%A9%20Git%20Bash%20Here%20%23%201%E3%80%81%E6%B5%8B%E8%AF%95%20hugo,https%3A%2F%2Fthemes.gohugo.io%2F%20%23%204%E3%80%81cd%20webName%20%E8%BF%9B%E5%85%A5%E7%AB%99%E7%82%B9%E7%9B%AE%E5%BD%95%20%EF%BC%8C%E6%89%A7%E8%A1%8C%E5%91%BD%E4%BB%A4%20hugo%20server)

![](static/XLdsbv2H0olUluxA6WMcMw2xnve.png)

（2）**启用主题**

在 hugo.toml 中添加一句 `theme='hugo-theme-stack'`

![](static/NJ6NbMfbIoVmH5xSrzUcIzMVnBe.png)

（3）启动 Hugo 的开发服务器查看站点

```python
hugo server
```

![](static/KW6PbOUfSoqGpUx6Cozc0yUmnqg.png)

（4）修改配置文件和内容

参考：[【Hugo】Stack 主题的使用记录_hugo stack-CSDN 博客](https://blog.csdn.net/2201_75288929/article/details/132507563?spm=1001.2101.3001.6650.2&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-2-132507563-blog-120890571.235%5Ev43%5Epc_blog_bottom_relevance_base5&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-2-132507563-blog-120890571.235%5Ev43%5Epc_blog_bottom_relevance_base5&utm_relevant_index=5)

```python
mv hugo.toml hugo.toml.bak
cp themes/hugo-theme-stack/exampleSite/config.yaml .
```

## 运行

![](static/PKYWbuh3ZovW7rxnLuHct7C2n8e)

# **发布内容**

1. `hugo`  命令可以将你写的 Markdown 文件生成静态 HTML 网页，生成的 HTML 文件默认存放在 `public` 文件夹中。
2. 因为 `hugo`  生成的静态 HTML 网页文件默认存放在  `public`  文件中，所以推送网页内容只需要把  `public`  中的 HTML 网页文件发布到 GitHub Pages 仓库中。
3. 将  `public`  文件夹初始化为 Git 仓库，并设置默认主分支名为  `main`。这么做的原因是：

   - GitHub 创建仓库时生成的默认主分支名是 `main`
   - 用 `git init` 初始化 Git 仓库时创建的默认主分支名是 `master`
   - 将 `git init` 创建的 `master` 修改成 `main` ，再推送给远端仓库 `<username>.github.io` ，这样才不会报错。

```shell
cd public
git init -b main           # 这种方法我不行
git branch -m master main  # 这种可以
```

![](static/VRpOballaophVmxs3J9cprrQnVg.png)

1. 将 `public`  文件夹关联远程 GitHub Pages 仓库，使用 GitHub Pages 仓库的 SSH 链接。
   ⚠ 注意：要让 SSH 链接起作用，需要你添加过 SSH Key。如果你没有设置过 SSH Key，需要添加。
   ![](static/GhgZbr3WYorBo4xVlR8c69o9nag)
2. 链接到 ssh

```shell
git remote add origin git@github.com:xiaoAugenstern/xiaoAugenstern.github.io.git
```

1. 推送博客源仓库的  `public`  文件夹中的 HTML 网页文件到 GitHub Pages 仓库 中，在推送仓库内容前要先用 `git pull --rebase origin main` 和远端仓库同步，否则会报错。

```shell
git pull --rebase origin main
git add .
git commit -m "...(修改的信息)"git push origin main
```

1. 转到 GitHub 查看 GitHub Pages 仓库中是否存在刚刚推送的文件，存在则代表推送成功。

![](static/GqSsbf1yCoyVnCxt4o5czt2inmb.png)

可以通过域名访问了 [https://xiaoAugenstern.github.io/](https://xiaoAugenstern.github.io/)

![](static/KtAKbb31goMTu8xLrCxc8kbanys.png)

# 装修我的个人主页

## 写博客

写 markdown 文档感觉格式不好看

别人给的建议 [建站技术 | 使用 Hugo+Stack 简单搭建一个博客](https://blog.reincarnatey.net/2023/build-hugo-blog-with-stack-mod/#%E4%BD%BF%E7%94%A8hugo%E5%88%9B%E5%BB%BA%E6%96%87%E7%AB%A0)：

> 曾经听过 Typora 的大名，然而不幸的是该编辑器已经转为收费且优化不足，因此这里推荐免费开源且好用的 [MarkText](https://github.com/marktext/marktext)。
> 安装方法很简单，[release](https://github.com/marktext/marktext/releases) 里面下载对应的版本安装即可。不过在我写这篇博客的时候 MarkText 还没有做好国际化的准备，因此尽管已经（看起来）有中文语言文件却无法切换语言。
> 这里推荐一个大佬的汉化版本 [marktext-chinese-language-pack](https://github.com/chinayangxiaowei/marktext-chinese-language-pack)，可以直接在该仓库的 [release](https://github.com/chinayangxiaowei/marktext-chinese-language-pack/releases) 仓库里下载对应版本的压缩包，替换到原版安装目录就好了（或者不安装原版直接使用汉化的程序文件，应该是直接可以用的，不过我比较喜欢通过官方安装器安装一遍以免注册表或者启动栏之类的问题）。
> 打开之后应该就是中文了，简单设置后直接输入便可以开始进行内容的编写了。

我是用飞书先写，然后再转 markdown 格式

[【飞书小技巧】——飞书文档转 markdown 详细教程_飞书文章下载为 markdown-CSDN 博客](https://blog.csdn.net/qq_39811006/article/details/135902394)
